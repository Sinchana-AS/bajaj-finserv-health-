package com.bajaj.health;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
public class App implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(App.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        RestTemplate restTemplate = new RestTemplate();

        // Step 1: Generate Webhook
        String generateWebhookUrl = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";

        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("name", "Sinchana A S");
        requestBody.put("regNo", "PES1UG22CS595"); // replace with your regNo
        requestBody.put("email", "s23391117@gmail.com");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Map<String, String>> request = new HttpEntity<>(requestBody, headers);

        ResponseEntity<Map> response = restTemplate.postForEntity(generateWebhookUrl, request, Map.class);

        Map<String, Object> body = response.getBody();
        if (body == null) {
            System.out.println("Failed to generate webhook.");
            return;
        }

        String webhookUrl = (String) body.get("webhook");
        String accessToken = (String) body.get("accessToken");

        System.out.println("Webhook URL: " + webhookUrl);
        System.out.println("Access Token: " + accessToken);

        // Step 2: Solve SQL problem
        String finalQuery = solveSQLProblem(); // <-- REPLACE THIS WITH YOUR FINAL SQL QUERY

        // Step 3: Submit SQL query to webhook
        Map<String, String> submitBody = new HashMap<>();
        submitBody.put("finalQuery", finalQuery);

        HttpHeaders submitHeaders = new HttpHeaders();
        submitHeaders.setContentType(MediaType.APPLICATION_JSON);
        submitHeaders.set("Authorization", accessToken); // JWT token

        HttpEntity<Map<String, String>> submitRequest = new HttpEntity<>(submitBody, submitHeaders);

        ResponseEntity<String> submitResponse = restTemplate.postForEntity(webhookUrl, submitRequest, String.class);

        System.out.println("Submission Response: " + submitResponse.getStatusCode());
        System.out.println(submitResponse.getBody());
    }

    // Replace the placeholder below with your SQL query
    private String solveSQLProblem() {
    return "SELECT p.AMOUNT AS SALARY, CONCAT(e.FIRST_NAME, ' ', e.LAST_NAME) AS NAME, " +
           "FLOOR(DATEDIFF(CURDATE(), e.DOB)/365) AS AGE, d.DEPARTMENT_NAME " +
           "FROM PAYMENTS p " +
           "JOIN EMPLOYEE e ON p.EMP_ID = e.EMP_ID " +
           "JOIN DEPARTMENT d ON e.DEPARTMENT = d.DEPARTMENT_ID " +
           "WHERE DAY(p.PAYMENT_TIME) <> 1 " +
           "AND p.AMOUNT = (SELECT MAX(AMOUNT) FROM PAYMENTS WHERE DAY(PAYMENT_TIME) <> 1)";
}

}
